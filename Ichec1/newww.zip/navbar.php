<header id="header">
<div class="container">

  <div id="logo" class="pull-left">
	<h1><a href="index.php" class="scrollto">ICheEC</a></h1>
	<!-- Uncomment below if you prefer to use an image logo -->
	<!-- <a href="#body"><img src="img/logo.png" alt="" title="" /></a>-->
  </div>

  <nav id="nav-menu-container">
	<ul class="nav-menu">
	  <li class="menu-active"><a href="index">Home</a></li>
	  <li><a href="committee">Committee</a></li>
	  <li><a href="paper_submit">Paper Submission</a></li>
	  <li><a href="speakers">Keynote Speakers</a></li>
	  <!-- <li class="menu-has-children"><a href="">About ICCCE</a>
		<ul>
		  <li><a href="sub.html">Submission</a></li>
	      <li><a href="reg.html">Registration</a></li>
		  <li><a href="venue.html">Venue</a></li>
		 	  <li><a href="schedule.html">Schedule</a></li>
		  <li><a href="visa.html">Visa</a></li>
		  <li><a href="news.html">News</a></li>
		</ul>
	  </li> -->
	  
	  <!-- <li class="menu-has-children"><a href="">Past Edition</a>
		<ul>
		  <li><a href="2020.html">ICCCE 2020</a></li>
		  <li><a href="2019.html">ICCCE 2019</a></li>
		  <li><a href="2018.html">ICCCE 2018</a></li>
		  <li><a href="2017.html">ICCCE 2017</a></li>
		  <li><a href="history.html">History</a></li>
		</ul>
	  </li> -->
	  <li><a href="contact_us">Contact</a></li>
	</ul>
  </nav><!-- #nav-menu-container -->
</div>
</header>