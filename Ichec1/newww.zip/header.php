<section id="topbar" class="d-none d-lg-block">
<div class="container clearfix">
  <div class="contact-info float-left">
	<i class="fa fa-envelope-o"></i> <a href="mailto:icecnitj2021@gmail.com">
	icecnitj2021@gmail.com</a>
	<i class="fa fa-phone"></i> +91-9956356951
  </div>
  <div class="social-links float-right">
	<a href="https://twitter.com/login" class="twitter"><i class="fa fa-twitter"></i></a>
	<a href="https://www.facebook.com/" class="facebook"><i class="fa fa-facebook"></i></a>
	<a href="https://www.instagram.com/?hl=en" class="instagram"><i class="fa fa-instagram"></i></a>
	<a href="" class="google-plus"><i class="fa fa-google-plus"></i></a>
	<a href="" class="linkedin"><i class="fa fa-linkedin"></i></a>
  </div>
</div>
</section>