<footer id="footer">
<div class="container">
  <div class="copyright">Copyright © 20<span lang="zh-cn">21 </span>All Rights Reserved International Chemical Engineering Conference, <br> Department of Chemical Engineering NIT Jalandhar
				</div>
  <div class="credits"><a href="developer">Govind Suman</a></div>
</div>
</footer>