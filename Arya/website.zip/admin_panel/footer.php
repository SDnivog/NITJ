  <footer class="main-footer">
    <strong>Copyright &copy; 2020 <a href="http://trando.in/">Team Trando</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
    </div>
  </footer>