<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IChEC-2021	</title>
    <link rel="stylesheet" href="css\bootstrap.min.css">
    <!-- <link rel="stylesheet" href="css\main.css"> -->
    <script src="https://kit.fontawesome.com/96ab48350d.js" crossorigin="anonymous"></script>
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> -->
    <style>
    *{
      background-color: rgba(0,0,0,0);
      
    }
    body{
       background-image: url('images/logo.jpeg');
       background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: center;

  background-size:auto;
       /* background-size: cover; */
       /* max-width: 100%; */
    }
    </style>
</head>
<body>

<?php include('navbar.php'); ?>



<!-- <div class="" style="max-height:500px;">

<img src="images/chemical.jpg" style="width: 100%;" alt="">

</div> -->

<div class="container-fluid " style="padding-top: 80px;">
   <div class="row">
    <div class="col-md-12" style="color:#fff;max-height:300px;">

    <h1 style="color: #04122b;font-weight:bold;" class="text-center">Chemical Engineering Department, NIT Jalandhar</h1>


        <h2 style="color: #080835;font-weight:bold;" class="text-center">International Chemical Engineering Conference 2021</h2>
        <h6 style="color: #080835;font-weight:bold;" class="text-center">(100 years of glorious chemical engineering)</h6>  

         

        <!-- <img src="images/logo.jpeg" alt="" style="" class="text-center"> -->

      </div>
   </div>
</div>


<div class="container-fluid " style="margin-top: 300px;">
   <div class="row">
    <div class="col-md-12" style="background-color:#010113; color:#fff;">
           <h2 class="text-center py-2" style="font-weight: bold;">About the Conference</h2>
             <p style="text-align: justify;" class="py-2">Over the last 100 years, chemical engineering has expanded its horizon in each and every segment of engineering be it production for industrial growth or for mankind. Numerous research and development activities have been conducted at macro, micro, and nano-scale levels to cut down the material and processing cost. Several new chemical engineering allied branches have emerged with great research thrust.
              This conference is aimed to showcase the various innovation over the last 100 years in chemical engineering and its allied branches. Researchers working in chemical and all its allied branches are invited to submit their manuscript on the following themes
              Chemical engineering, Heat transfer, Reaction engineering, Modeling & simulation, Process control, Transport processes, Separation processes, Diffusion and Drying, Computational Fluid Dynamics, Bio and Food Processing, Energy and Environment, Sustainable engineering, Artificial intelligence and machine learning, Process Design and Scale-Up, Material Science, Coatings
             </p>
      </div>
   </div>
</div>

<div class="container-fluid py-4" style="background-color:#080835;min-height:300px;">
   <div class="row" >
    <div class="col-md-4" style="margin-top:50px;">
           <div class="card">
             <div class="card-header text-center">DAY - 1</div>
               <div class="card-body">
                  <img src="images/person1.jpg" alt="" style="width: 100%; height:250px;"><br>
                  <p>Researchers working in chemical and all its allied branches are invited to submit their manuscript on the following themes Chemical engineering, Heat transfer, Reaction engineering, Modeling & simulation, Process control, Transport processes, Separation processes, Diffusion and Drying, Computational Fluid Dynamics, Bio and Food Processing, Energy and Environment, Sustainable engineering, Artificial intelligence and machine learning, Process Design and Scale-Up, Material Science, Coatings</p>
               </div>
           </div>
      </div>

      <div class="col-md-4" style="margin-top:50px;">
           <div class="card">
             <div class="card-header text-center">DAY - 2</div>
               <div class="card-body">
                  <img src="images/person1.jpg" alt="" style="width: 100%; height:250px;"><br>
                  <p>Researchers working in chemical and all its allied branches are invited to submit their manuscript on the following themes Chemical engineering, Heat transfer, Reaction engineering, Modeling & simulation, Process control, Transport processes, Separation processes, Diffusion and Drying, Computational Fluid Dynamics, Bio and Food Processing, Energy and Environment, Sustainable engineering, Artificial intelligence and machine learning, Process Design and Scale-Up, Material Science, Coatings</p>
               </div>
           </div>
      </div>
      <div class="col-md-4" style="margin-top:50px;">
           <div class="card">
             <div class="card-header text-center">DAY - 3</div>
               <div class="card-body">
                  <img src="images/person1.jpg" alt="" style="width: 100%; height:250px;"><br>
                  <p>Researchers working in chemical and all its allied branches are invited to submit their manuscript on the following themes Chemical engineering, Heat transfer, Reaction engineering, Modeling & simulation, Process control, Transport processes, Separation processes, Diffusion and Drying, Computational Fluid Dynamics, Bio and Food Processing, Energy and Environment, Sustainable engineering, Artificial intelligence and machine learning, Process Design and Scale-Up, Material Science, Coatings</p>
               </div>
           </div>
      </div>

   </div>
</div>


<div class="container-fluid py-4" style="padding-top: 50px;background-color:#fff;">
   <div class="row">
    <div class="col-md-12" style="min-height:500px;">
    
    <h3 class="text-center" style="color: #6464a2; text-align:justify">The goal of this event is to bring leaders in information technology together from across the globe.</h3>

<img src="images/meeting.jpg" alt="" style="width: 100%; max-height:550px;padding-top:20px;">        

      </div>
   </div>
</div>


<div class="container-fluid py-4" style="padding-top: 50px;background-color:#082d73;">

<h3 class="text-center text-light">The Speakers</h3><br>

   <div class="row">

    <div class="col-md-3 mb-2" style="min-height:300px;">
     <div class="card">
        <div class="card-body">
            <img src="images/person4.jpg" alt="" style="width: 100%; max-height:250px;"><br>
            <h5 class="text-center py-1">Govind Suman</h5>
            <p style="text-align: justify;">Researchers working in chemical and all its allied branches are invited to submit their manuscript on the following themes Chemical engineering, Heat transfer, Reaction engineering, Modeling & simulation, Process control.</p>
        </div>
     </div>
      </div>

      <div class="col-md-3 mb-2" style="min-height:300px;">
     <div class="card">
        <div class="card-body">
            <img src="images/person4.jpg" alt="" style="width: 100%; max-height:250px;"><br>
            <h5 class="text-center py-1">Govind Suman</h5>
            <p style="text-align: justify;">Researchers working in chemical and all its allied branches are invited to submit their manuscript on the following themes Chemical engineering, Heat transfer, Reaction engineering, Modeling & simulation, Process control.</p>
        </div>
     </div>
      </div>
      <div class="col-md-3 mb-2" style="min-height:300px;">
     <div class="card">
        <div class="card-body">
            <img src="images/person4.jpg" alt="" style="width: 100%; max-height:250px;"><br>
            <h5 class="text-center py-1">Govind Suman</h5>
            <p style="text-align: justify;">Researchers working in chemical and all its allied branches are invited to submit their manuscript on the following themes Chemical engineering, Heat transfer, Reaction engineering, Modeling & simulation, Process control.</p>
        </div>
     </div>
      </div>
      <div class="col-md-3 mb-2" style="min-height:300px;">
     <div class="card">
        <div class="card-body">
            <img src="images/person4.jpg" alt="" style="width: 100%; max-height:250px;"><br>
            <h5 class="text-center py-1">Govind Suman</h5>
            <p style="text-align: justify;">Researchers working in chemical and all its allied branches are invited to submit their manuscript on the following themes Chemical engineering, Heat transfer, Reaction engineering, Modeling & simulation, Process control.</p>
        </div>
     </div>
      </div>
      <div class="col-md-3 mb-2" style="min-height:300px;">
     <div class="card">
        <div class="card-body">
            <img src="images/person4.jpg" alt="" style="width: 100%; max-height:250px;"><br>
            <h5 class="text-center py-1">Govind Suman</h5>
            <p style="text-align: justify;">Researchers working in chemical and all its allied branches are invited to submit their manuscript on the following themes Chemical engineering, Heat transfer, Reaction engineering, Modeling & simulation, Process control.</p>
        </div>
     </div>
      </div>
      <div class="col-md-3 mb-2" style="min-height:300px;">
     <div class="card">
        <div class="card-body">
            <img src="images/person4.jpg" alt="" style="width: 100%; max-height:250px;"><br>
            <h5 class="text-center py-1">Govind Suman</h5>
            <p style="text-align: justify;">Researchers working in chemical and all its allied branches are invited to submit their manuscript on the following themes Chemical engineering, Heat transfer, Reaction engineering, Modeling & simulation, Process control.</p>
        </div>
     </div>
      </div>
      <div class="col-md-3 mb-2" style="min-height:300px;">
     <div class="card">
        <div class="card-body">
            <img src="images/person4.jpg" alt="" style="width: 100%; max-height:250px;"><br>
            <h5 class="text-center py-1">Govind Suman</h5>
            <p style="text-align: justify;">Researchers working in chemical and all its allied branches are invited to submit their manuscript on the following themes Chemical engineering, Heat transfer, Reaction engineering, Modeling & simulation, Process control.</p>
        </div>
     </div>
      </div>
      <div class="col-md-3 mb-2" style="min-height:300px;">
     <div class="card">
        <div class="card-body">
            <img src="images/person4.jpg" alt="" style="width: 100%; max-height:250px;"><br>
            <h5 class="text-center py-1">Govind Suman</h5>
            <p style="text-align: justify;">Researchers working in chemical and all its allied branches are invited to submit their manuscript on the following themes Chemical engineering, Heat transfer, Reaction engineering, Modeling & simulation, Process control.</p>
        </div>
     </div>
      </div>

   </div>
</div>


<div class="container-fluid py-4" style="padding-top: 50px;background-color:#23488e;">

   <div class="row">

      <div class="col-md-12" style="min-height: 150px;">
          
         <h2 style="text-align: center; color:#fff;"> Let us know if you'll be attending!</h2><br>
         <h2 style="text-align: center;"><button class="btn btn-light "><a href="#">RSVP</a></button></h2>

      </div>


   </div>
</div>


<?php include('footer.php'); ?>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
<script> $('#year').text(new Date().getFullYear()); </script>
</body>
</html>