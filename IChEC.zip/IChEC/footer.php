<div class="container-fluid py-4" style="background-color:#04122b;">

   <div class="row">

      <div class="col-md-12" style="max-height: 100px;">
          
         <h6 style="text-align: center; color:#fff;"> &copy; Copyright 2021, All Rights Reserved International Chemical Engineering Conference</h6>
         <h6 style="text-align: center; color:#fff;"> Department of Chemical Engineering NIT Jalandhar</h6>

      </div>


   </div>
</div>