<?php 
$DSN ='mysql:host = localhost; dbname=nitj_arya'; 
$ConnectingDB = new PDO($DSN,'root','');

 ?>

 